1. Load all files into local folder
2. Run main file
3. Enter 1 for TSP, 2 for Wine, 3 for Polygon
4. Close figures when desired.
5. Rerun after terminal says goodbye to view any other processes