WINE CLASSIFICATION PROBLEM:

This problem is to try to classify wine by 13 extracted attributes. The
problem should be relatively simple to get high performance, but difficult 
to classify every exemplar. 

Number of Exemplars:  178

Data Elements per Exemplar: 13 continuous
 	1) Alcohol
 	2) Malic acid
 	3) Ash
	4) Alcalinity of ash  
 	5) Magnesium
	6) Total phenols
 	7) Flavanoids
 	8) Nonflavanoid phenols
 	9) Proanthocyanins
	10)Color intensity
 	11)Hue
 	12)OD280/OD315 of diluted wines
 	13)Proline            

Number of Outputs: 3

Output Encoding: Output1 = Wine1, Output2 = Wine2, Output3 = Wine3

Problem Type: Classification

Problem Source: UCI Machine learning Database
ftp://ftp.ics.uci.edu/pub/machine-learning-databases/wine

Problem Discussion: ftp://ftp.ics.uci.edu/pub/machine-learning-
databases/wine

